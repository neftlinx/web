<?php
$setting = [
  "mail_to" => "MyEmail@gmail.com",
  "debug_mode" => false
]
?>
